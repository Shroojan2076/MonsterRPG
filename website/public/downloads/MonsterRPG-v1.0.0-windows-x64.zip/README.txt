=====================================================
 MonsterRPG - Official Windows Release (v1.0.0)
 2D Retro Adventure in Modern C++20 and SFML
=====================================================

QUICKSTART:
1. Extract all files to a folder on your PC.
2. Ensure the "assets" folder is in the same directory as "MonsterRPG.exe".
3. Double-click "MonsterRPG.exe" to launch the game!

CONTROLS:
- [W, A, S, D] or Arrow Keys : Move (Tap to turn without stepping)
- [Left Shift] (Hold)        : Run / Sprint (120 px/sec)
- [E] or [Space]             : Talk / Interact with NPCs & Props
- [1, 2, 3, 4]               : Select Battle Commands and Moves
- [Esc]                      : Back / Cancel

STARTING YOUR JOURNEY:
- You begin in Oakdale Town Square.
- Walk North-West to enter Professor Oak's Research Lab.
- Speak with Prof. Oak behind the research desk to receive your starter Charmander!
- Once you receive your starter, your partner Pokémon will follow you everywhere.
- Head East into Whispering Woods to explore, catch wild monsters, and face the Guardian!

WEBSITE & DOCS:
https://github.com/MonsterRPG
